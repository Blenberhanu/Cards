import * as React from 'react';
import { IGridLayoutProps, IGridLayoutState } from './GridLayout.types';
export declare class GridLayout extends React.Component<IGridLayoutProps, IGridLayoutState> {
    private _columnCount;
    private _columnWidth;
    private _rowHeight;
    private _isCompact;
    render(): React.ReactElement<IGridLayoutProps>;
    private _getItemCountForPage;
    private _getPageHeight;
    private _onRenderCell;
}
//# sourceMappingURL=GridLayout.d.ts.map