declare const styles: {
    padding: string;
    minWidth: string;
    maxWidth: string;
    compactThreshold: string;
    rowsPerPage: string;
    gridLayout: string;
};
export default styles;
//# sourceMappingURL=GridLayout.module.scss.d.ts.map