declare const styles: {};
export default styles;
//# sourceMappingURL=temporary.scss.d.ts.map