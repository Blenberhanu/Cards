import * as React from 'react';
import { IPagingProps, IPagingState } from "./index";
/**
 * A custom pagination control designed to look & feel like Office UI Fabric
 */
export declare class Paging extends React.Component<IPagingProps, IPagingState> {
    render(): React.ReactElement<IPagingProps>;
    /**
     * Increments the page number unless we're on the last page
     */
    private _nextPage;
    /**
     * Decrements the page number unless we're on the first page
     */
    private _prevPage;
    /**
     * Calculates how many pages there will be
     */
    private _getNumberOfPages;
}
//# sourceMappingURL=Paging.d.ts.map