declare const styles: {
    Paging: string;
    next: string;
    prev: string;
    noPageNum: string;
};
export default styles;
//# sourceMappingURL=Paging.module.scss.d.ts.map