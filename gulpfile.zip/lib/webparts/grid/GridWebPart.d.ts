import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IGridWebPartProps {
    description: string;
}
export default class GridWebPart extends BaseClientSideWebPart<IGridWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
}
//# sourceMappingURL=GridWebPart.d.ts.map