import * as React from 'react';
import { IGridProps, IGridState, ISPDocuments } from './Grid.types';
import "bootstrap/dist/css/bootstrap.min.css";
export default class Grid extends React.Component<IGridProps, IGridState> {
    constructor(props: IGridProps);
    private Libitems;
    private currentSelection;
    handleClick(event: any): void;
    private _CustomSearch;
    getPreviewUrl(path: any): any;
    _getListData(e: any): Promise<ISPDocuments>;
    _getParentCategories(): Promise<ISPDocuments>;
    gethostName(): string;
    private _showDialog;
    private _closeDialog;
    onDropdownChange: (event: any, option?: any, index?: number) => void;
    render(): React.ReactElement<IGridProps>;
    private _onRenderGridItem;
    handleChange(e: any): void;
}
//# sourceMappingURL=Grid.d.ts.map