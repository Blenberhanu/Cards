declare const styles: {
    grid: string;
    documentTile: string;
    gridItem: string;
};
export default styles;
//# sourceMappingURL=Grid.module.scss.d.ts.map