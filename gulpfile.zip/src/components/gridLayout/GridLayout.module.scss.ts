/* tslint:disable */
require("./GridLayout.module.css");
const styles = {
  padding: '20',
  minWidth: '210',
  maxWidth: '320',
  compactThreshold: '480',
  rowsPerPage: '3',
  gridLayout: 'gridLayout_06366fc0'
};

export default styles;
/* tslint:enable */