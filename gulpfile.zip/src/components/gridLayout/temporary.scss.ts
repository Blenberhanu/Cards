/* tslint:disable */
require("./temporary.css");
const styles = {

};

export default styles;
/* tslint:enable */