/* tslint:disable */
require("./Paging.module.css");
const styles = {
  Paging: 'Paging_c8931aa7',
  next: 'next_c8931aa7',
  prev: 'prev_c8931aa7',
  noPageNum: 'noPageNum_c8931aa7'
};

export default styles;
/* tslint:enable */