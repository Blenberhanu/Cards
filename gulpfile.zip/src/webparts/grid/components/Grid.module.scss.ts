/* tslint:disable */
require("./Grid.module.css");
const styles = {
  grid: 'grid_3aa32b9a',
  documentTile: 'documentTile_3aa32b9a',
  gridItem: 'gridItem_3aa32b9a'
};

export default styles;
/* tslint:enable */