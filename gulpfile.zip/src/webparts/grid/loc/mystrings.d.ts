declare interface IGridWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GridWebPartStrings' {
  const strings: IGridWebPartStrings;
  export = strings;
}
